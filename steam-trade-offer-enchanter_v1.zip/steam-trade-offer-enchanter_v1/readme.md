


source used/refer : 

1. presistence background loop solution (Offscreen API in Chrome 109+) : https://stackoverflow.com/questions/66618136/persistent-service-worker-in-chrome-extension



